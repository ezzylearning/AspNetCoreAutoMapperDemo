﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks; 
using AspNetCoreAutoMapperDemo.Models;

namespace AspNetCoreAutoMapperDemo.Services
{
    public interface IEmployeeService
    {
        List<EmployeeModel> GetEmployees(); 
    }
}
