﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

using AspNetCoreAutoMapperDemo.Models;
using AspNetCoreAutoMapperDemo.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AspNetCoreAutoMapperDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEmployeeService _employeeService;
        
        public HomeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        public IActionResult Index()
        {
            return View(_employeeService.GetEmployees());
        } 
    }
}
